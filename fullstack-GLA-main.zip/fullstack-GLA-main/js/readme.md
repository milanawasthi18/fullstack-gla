JS Notes of SHiv Kumar Verma sir
