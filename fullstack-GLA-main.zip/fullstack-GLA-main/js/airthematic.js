let a = 20;
//a = a+1;
//a=a-1;
//a=a*1;
//a=a/2;
//a=a**2;
//augmented expressions
//a += 1; and same for others
console.log(a);

//operators precedence
// 1. ()
// 2. exponents
// 3. *, /,%
// 4. +,-